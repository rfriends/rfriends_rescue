#!/bin/sh
# -----------------------------------------
# rfriends3 (radiko radiru録音ツール)
# ipv4を取得しrfriends_serverを実行する
# ポートを指定する場合は、rf3server.sh 8000
#
# 2023/07/19 macのipコマンドに対応（scopeなし）
# -----------------------------------------

echo -----------------------------------------------
echo ipv4を取得しrfriends3_serverを実行します。
echo -----------------------------------------------

port=8000

if [ $# -eq 1 ]; then
    port=$1
fi

# ip=`ifconfig | grep "inet " | grep -v "127.0.0.1" | sed -e 's/^ *//' | cut -d\  -f 2`
# ip -4 a show scope global up | grep inet | sed -e 's/^ *//' | cut -d\  -f 2 | cut -d/ -f 1

ip=`ip a | grep "inet " | grep -m1 -v "127.0.0.1" | sed -e 's/^ *//' | cut -d\  -f 2 | cut -d/ -f 1`

server=${ip}:${port}
# -----------------------------------------
sh rfriends3_server.sh ${server}
echo done
# -----------------------------------------
